package com.example.thierry.anlisesensorial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FinalScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_screen);
        Button btn = (Button) findViewById(R.id.realizar);

    }

    public void backCode(View v){
        Intent inten = new Intent(FinalScreen.this,codeProduct.class);
        startActivity(inten);
    }

    public void backBegin(View v){
        Intent inten = new Intent(FinalScreen.this,MainActivity.class);
        startActivity(inten);
    }
}
