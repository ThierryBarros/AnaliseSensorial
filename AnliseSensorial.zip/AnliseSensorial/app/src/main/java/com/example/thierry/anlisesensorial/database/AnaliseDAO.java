package com.example.thierry.anlisesensorial.database;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;

/**
 * Created by Thierry on 2/22/2018.
 */

public class AnaliseDAO {

    private static final String URL = "http://192.168.15.66:8080/AnaliseWeb/services/AnaliseDAO?wsdl";
    private static final String NAMESPACE = "http://analise.com.br";
    private static final String INSERIR = "inserirAnalise";

    public boolean inserirAnalise(AnaliseWeb analise) {
        SoapObject inserirAnalise = new SoapObject(NAMESPACE,INSERIR);

        SoapObject anal = new SoapObject(NAMESPACE,"analise");

        anal.addProperty("id",analise.getId());
        anal.addProperty("aparencia",analise.getAparencia());
        anal.addProperty("aroma",analise.getAroma());
        anal.addProperty("avalglobal",analise.getAvalglobal());
        anal.addProperty("codigo",analise.getCodigo());
        anal.addProperty("consistencia",analise.getConsistencia());
        anal.addProperty("cor",analise.getCor());
        anal.addProperty("docura",analise.getDocura());
        anal.addProperty("maciez",analise.getMaciez());
        anal.addProperty("odor",analise.getOdor());
        anal.addProperty("sabor",analise.getSabor());
        anal.addProperty("saborresidual",analise.getSaborresidual());
        anal.addProperty("textura",analise.getTextura());

        inserirAnalise.addSoapObject(anal);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

        envelope.setOutputSoapObject(inserirAnalise);

        envelope.implicitTypes = true;

        HttpTransportSE http = new HttpTransportSE(URL);

        try {
            http.call("urn:"+ INSERIR,envelope);

            SoapPrimitive resposta = (SoapPrimitive) envelope.getResponse();

            return Boolean.parseBoolean(resposta.toString());

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }
}
