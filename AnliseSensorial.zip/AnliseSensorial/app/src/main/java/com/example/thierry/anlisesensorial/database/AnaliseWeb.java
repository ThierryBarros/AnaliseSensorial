package com.example.thierry.anlisesensorial.database;

/**
 * Created by Thierry on 2/22/2018.
 */

public class AnaliseWeb {
    private int id;
    private int codigo;
    private int aparencia;
    private int sabor;
    private int aroma;
    private int saborresidual;
    private int docura;
    private int textura;
    private int odor;
    private int maciez;
    private int cor;
    private int consistencia;
    private int avalglobal;

    public AnaliseWeb() {

    }

    public AnaliseWeb(int id, int codigo, int aparencia, int sabor, int aroma, int saborresidual, int docura, int textura,
                   int odor, int maciez, int cor, int consistencia, int avalglobal) {
        super();
        this.id = id;
        this.codigo = codigo;
        this.aparencia = aparencia;
        this.sabor = sabor;
        this.aroma = aroma;
        this.saborresidual = saborresidual;
        this.docura = docura;
        this.textura = textura;
        this.odor = odor;
        this.maciez = maciez;
        this.cor = cor;
        this.consistencia = consistencia;
        this.avalglobal = avalglobal;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getAparencia() {
        return aparencia;
    }

    public void setAparencia(int aparencia) {
        this.aparencia = aparencia;
    }

    public int getSabor() {
        return sabor;
    }

    public void setSabor(int sabor) {
        this.sabor = sabor;
    }

    public int getAroma() {
        return aroma;
    }

    public void setAroma(int aroma) {
        this.aroma = aroma;
    }

    public int getSaborresidual() {
        return saborresidual;
    }

    public void setSaborresidual(int saborresidual) {
        this.saborresidual = saborresidual;
    }

    public int getDocura() {
        return docura;
    }

    public void setDocura(int docura) {
        this.docura = docura;
    }

    public int getTextura() {
        return textura;
    }

    public void setTextura(int textura) {
        this.textura = textura;
    }

    public int getOdor() {
        return odor;
    }

    public void setOdor(int odor) {
        this.odor = odor;
    }

    public int getMaciez() {
        return maciez;
    }

    public void setMaciez(int maciez) {
        this.maciez = maciez;
    }

    public int getCor() {
        return cor;
    }

    public void setCor(int cor) {
        this.cor = cor;
    }

    public int getConsistencia() {
        return consistencia;
    }

    public void setConsistencia(int consistencia) {
        this.consistencia = consistencia;
    }

    public int getAvalglobal() {
        return avalglobal;
    }

    public void setAvalglobal(int avalglobal) {
        this.avalglobal = avalglobal;
    }

}
