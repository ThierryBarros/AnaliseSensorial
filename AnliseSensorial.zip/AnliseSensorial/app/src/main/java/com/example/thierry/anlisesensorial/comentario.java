package com.example.thierry.anlisesensorial;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.StrictMode;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.database.sqlite.*;
import android.database.*;
import android.widget.TextView;

import com.example.thierry.anlisesensorial.database.AnaliseDAO;
import com.example.thierry.anlisesensorial.database.AnaliseWeb;
import com.example.thierry.anlisesensorial.database.DataBase;
import com.example.thierry.anlisesensorial.dominio.RepositorioAnalise;

import org.w3c.dom.Text;

public class comentario extends AppCompatActivity {

    private static final String PREF_NAME = "ComentarioActivityPrefences";
    private static final String CODE_PREF_NAME = "CodeProductActivityPrefences";
    private static final String ANALISE_PREF_NAME = "AnaliseActivityPrefences";

    private DataBase dataBase;
    private SQLiteDatabase conn;
    private RepositorioAnalise repositorioAnalise;
    private SharedPreferences.OnSharedPreferenceChangeListener callback = new SharedPreferences.OnSharedPreferenceChangeListener(){

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {

        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comentario);

    }

    private void insertValues(){
        //importante
//        try {
//            dataBase = new DataBase(this);
//            conn = dataBase.getWritableDatabase();
//
//            repositorioAnalise = new RepositorioAnalise(conn);
//
//            int valor = repositorioAnalise.buscaAnalise();
//
//            insertValues();
//            AlertDialog.Builder dlg =  new AlertDialog.Builder(this);
//            dlg.setMessage("Conexao criada com sucesso!");
//            dlg.setNeutralButton("OK",null);
//            dlg.show();
//        }catch(SQLException ex){
//            AlertDialog.Builder dlg =  new AlertDialog.Builder(this);
//            dlg.setMessage("Erro ao criar o banco!");
//            dlg.setNeutralButton("OK",null);
//            dlg.show();
//        }
//        //termina aq
//        SharedPreferences sp1 = getSharedPreferences(ANALISE_PREF_NAME,MODE_PRIVATE);
//        SharedPreferences sp2 = getSharedPreferences(CODE_PREF_NAME,MODE_PRIVATE);
//
//        int aparencia  = sp1.getInt("analise_aparencia_1",0);
//        int aroma = sp1.getInt("analise_aroma_1",0);
//        int saborresidual = sp1.getInt("analise_saborresidual_1",0);
//        int sabor = sp1.getInt("analise_sabor_1",0);
//        int docura = sp1.getInt("analise_doçura_1",0);
//        int textura = sp1.getInt("analise_textura_1",0);
//
//        TextView tt = (TextView)findViewById(R.id.tt);
//        tt.setText(String.valueOf(aparencia)+" "+String.valueOf(aroma)+" "+String.valueOf(saborresidual)+" "+String.valueOf(sabor)+" "+String.valueOf(docura)+" "+String.valueOf(textura));
//
//
//        int codigo = sp2.getInt("codigo_1",0);
//
//        repositorioAnalise.inserir(codigo,sabor,saborresidual,aparencia,aroma,textura,docura);
    }

    public void changeActivity(View v){
        inserirAnalise();
        Intent inten = new Intent(comentario.this,FinalScreen.class);
        startActivity(inten);
    }

    private void inserirAnalise() {
        AnaliseDAO dao = new AnaliseDAO();
        SharedPreferences sp2 = getSharedPreferences(CODE_PREF_NAME,MODE_PRIVATE);
        int codigo = sp2.getInt("codigo_1",0);

        SharedPreferences sp1 = getSharedPreferences(ANALISE_PREF_NAME,MODE_PRIVATE);
        int aparencia  = sp1.getInt("analise_aparencia_1",0);
        int aroma  = sp1.getInt("analise_aroma_1",0);
        int saborresidual  = sp1.getInt("analise_saborresidual_1",0);
        int sabor  = sp1.getInt("analise_sabor_1",0);
        int docura  = sp1.getInt("analise_doçura_1",0);
        int textura  = sp1.getInt("analise_textura_1",0);
        int odor  = sp1.getInt("analise_odor_1",0);
        int maciez  = sp1.getInt("analise_maciez_1",0);
        int cor  = sp1.getInt("analise_cor_1",0);
        int consistencia  = sp1.getInt("analise_consistencia_1",0);
        int avalglobal  = sp1.getInt("analise_avalGlobal_1",0);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }


        boolean resultado = dao.inserirAnalise(new AnaliseWeb(0,codigo,aparencia,sabor,aroma,saborresidual,docura,textura,odor,maciez,cor,consistencia,avalglobal));


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SharedPreferences sp1 = getSharedPreferences(PREF_NAME,MODE_PRIVATE);
        sp1.unregisterOnSharedPreferenceChangeListener(callback);
    }


    @Override
    protected void onStop() {
        super.onStop();
        SharedPreferences sp1 = getSharedPreferences(PREF_NAME,MODE_PRIVATE);
        SharedPreferences.Editor editor = sp1.edit();

        final EditText comentario = (EditText)findViewById(R.id.comentarios);
        editor.putString("comentario_1",comentario.getText().toString());

        editor.commit();

    }


}
