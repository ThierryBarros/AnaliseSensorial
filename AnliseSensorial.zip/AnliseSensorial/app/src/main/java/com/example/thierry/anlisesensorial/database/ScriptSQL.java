package com.example.thierry.anlisesensorial.database;

/**
 * Created by Thierry on 12/25/2017.
 */

public class ScriptSQL {
    public static String getCreateAnalise(){


        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("CREATE TABLE IF NOT EXISTS ANALISE( ");
        sqlBuilder.append("_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, ");
        sqlBuilder.append("codigo INTEGER, ");
        sqlBuilder.append("sabor INTEGER, ");
        sqlBuilder.append("saborresidual INTEGER, ");
        sqlBuilder.append("aparencia INTEGER, ");
        sqlBuilder.append("aroma INTEGER, ");
        sqlBuilder.append("textura INTEGER, ");
        sqlBuilder.append("docura INTEGER );");

        return sqlBuilder.toString();
    }
}
