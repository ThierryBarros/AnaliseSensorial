package com.example.thierry.anlisesensorial.database;

/**
 * Created by Thierry on 12/25/2017.
 */
import android.content.Context;
import android.database.sqlite.*;

import com.example.thierry.anlisesensorial.database.ScriptSQL;

public class DataBase extends SQLiteOpenHelper{

    public DataBase(Context context){
        super(context, "ANALISE", null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(ScriptSQL.getCreateAnalise());
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
